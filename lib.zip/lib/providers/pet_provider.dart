import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PetConfig {
  String name;
  String type;
  String color;
  String aura;
  String hat;
  String clothes;

  PetConfig({
    this.name = 'Calmi',
    this.type = 'cat',
    this.color = '#FF6B6B',
    this.aura = 'sparkles',
    this.hat = 'none',
    this.clothes = 'none',
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'color': color,
      'aura': aura,
      'hat': hat,
      'clothes': clothes,
    };
  }

  factory PetConfig.fromJson(Map<String, dynamic> json) {
    return PetConfig(
      name: json['name'] ?? 'Calmi',
      type: json['type'] ?? 'cat',
      color: json['color'] ?? '#FF6B6B',
      aura: json['aura'] ?? 'sparkles',
      hat: json['hat'] ?? 'none',
      clothes: json['clothes'] ?? 'none',
    );
  }
}

class PetProvider extends ChangeNotifier {
  PetConfig _config = PetConfig();

  PetProvider() {
    loadConfig();
  }

  PetConfig get config => _config;

  // Pet emoji mappings
  String getPetEmoji() {
    switch (_config.type) {
      case 'cat':
        return '🐱';
      case 'dog':
        return '🐶';
      case 'rabbit':
        return '🐰';
      case 'fox':
        return '🦊';
      case 'panda':
        return '🐼';
      case 'unicorn':
        return '🦄';
      default:
        return '🐱';
    }
  }

  String getAuraEmoji() {
    switch (_config.aura) {
      case 'sparkles':
        return '✨';
      case 'hearts':
        return '💕';
      case 'stars':
        return '⭐';
      case 'rainbow':
        return '🌈';
      case 'none':
      default:
        return '';
    }
  }

  String getHatEmoji() {
    switch (_config.hat) {
      case 'cap':
        return '🧢';
      case 'crown':
        return '👑';
      case 'wizard':
        return '🎩';
      case 'none':
      default:
        return '';
    }
  }

  String getClothesEmoji() {
    switch (_config.clothes) {
      case 'scarf':
        return '🧣';
      case 'bow':
        return '🎀';
      case 'cape':
        return '🦸';
      case 'none':
      default:
        return '';
    }
  }

  // Update methods
  void updateName(String name) {
    _config.name = name;
    notifyListeners();
    _saveConfig();
  }

  void updateType(String type) {
    _config.type = type;
    notifyListeners();
    _saveConfig();
  }

  void updateColor(String color) {
    _config.color = color;
    notifyListeners();
    _saveConfig();
  }

  void updateAura(String aura) {
    _config.aura = aura;
    notifyListeners();
    _saveConfig();
  }

  void updateHat(String hat) {
    _config.hat = hat;
    notifyListeners();
    _saveConfig();
  }

  void updateClothes(String clothes) {
    _config.clothes = clothes;
    notifyListeners();
    _saveConfig();
  }

  // Persistence
  Future<void> _saveConfig() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final configJson = _config.toJson();
      for (String key in configJson.keys) {
        await prefs.setString('pet_$key', configJson[key].toString());
      }
    } catch (e) {
      print('Error saving pet config: $e');
    }
  }

  Future<void> loadConfig() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _config = PetConfig(
        name: prefs.getString('pet_name') ?? 'Calmi',
        type: prefs.getString('pet_type') ?? 'cat',
        color: prefs.getString('pet_color') ?? '#FF6B6B',
        aura: prefs.getString('pet_aura') ?? 'sparkles',
        hat: prefs.getString('pet_hat') ?? 'none',
        clothes: prefs.getString('pet_clothes') ?? 'none',
      );
      notifyListeners();
    } catch (e) {
      print('Error loading pet config: $e');
    }
  }
}
