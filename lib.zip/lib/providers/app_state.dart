import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_screen.dart';

class AppState extends ChangeNotifier {
  AppScreen _currentScreen = AppScreen.home;
  bool _isFirstTime = true;
  String _userName = '';
  int _level = 12;
  int _experience = 2750;
  int _streak = 25;
  int _sessionsToday = 4;
  int _totalSessions = 156;
  int _dailyGoal = 5;
  List<String> _achievements = [];
  Map<String, int> _exerciseStats = {};

  // Getters
  AppScreen get currentScreen => _currentScreen;
  bool get isFirstTime => _isFirstTime;
  String get userName => _userName;
  int get level => _level;
  int get userLevel => _level;
  int get experience => _experience;
  int get userXP => _experience;
  int get streak => _streak;
  int get streakDays => _streak;
  int get sessionsToday => _sessionsToday;
  int get completedSessions => _sessionsToday;
  int get totalSessions => _totalSessions;
  int get dailyGoal => _dailyGoal;
  List<String> get achievements => _achievements;
  Map<String, int> get exerciseStats => _exerciseStats;

  AppState() {
    loadState();
  }

  // Navigation methods
  void navigateToScreen(AppScreen screen) {
    _currentScreen = screen;
    notifyListeners();
  }

  void navigateTo(AppScreen screen) {
    _currentScreen = screen;
    notifyListeners();
  }

  void navigateToHome() {
    _currentScreen = AppScreen.home;
    notifyListeners();
  }

  // User data methods
  void setUserName(String name) {
    _userName = name;
    notifyListeners();
    _saveState();
  }

  void completeFirstTimeSetup() {
    _isFirstTime = false;
    notifyListeners();
    _saveState();
  }

  void addXP(int xp) {
    _experience += xp;

    // Check for level up
    int newLevel = (_experience / 100).floor() + 1;
    if (newLevel > _level) {
      _level = newLevel;
      // Add level up achievement
      addAchievement('level_$newLevel');
    }

    notifyListeners();
    _saveState();
  }

  void addExperience(int xp) {
    addXP(xp);
  }

  void incrementStreak() {
    _streak++;

    // Add streak achievements
    if (_streak == 7) addAchievement('week_streak');
    if (_streak == 30) addAchievement('month_streak');
    if (_streak == 100) addAchievement('hundred_streak');

    notifyListeners();
    _saveState();
  }

  void resetStreak() {
    _streak = 0;
    notifyListeners();
    _saveState();
  }

  void completeSession(String exerciseType) {
    _sessionsToday++;

    // Update exercise stats
    _exerciseStats[exerciseType] = (_exerciseStats[exerciseType] ?? 0) + 1;

    // Add XP for completing session
    addXP(10);

    // Check for daily goal achievement
    if (_sessionsToday >= _dailyGoal) {
      addAchievement('daily_goal_${DateTime.now().day}');
    }

    // Check for exercise-specific achievements
    if (_exerciseStats[exerciseType] == 10) {
      addAchievement('${exerciseType}_master');
    }

    notifyListeners();
    _saveState();
  }

  void incrementSessionsToday() {
    _sessionsToday++;
    notifyListeners();
    _saveState();
  }

  void setDailyGoal(int goal) {
    _dailyGoal = goal;
    notifyListeners();
    _saveState();
  }

  void addAchievement(String achievementId) {
    if (!_achievements.contains(achievementId)) {
      _achievements.add(achievementId);
      notifyListeners();
      _saveState();
    }
  }

  void resetDailyProgress() {
    _sessionsToday = 0;
    notifyListeners();
    _saveState();
  }

  // Login methods
  void login() {
    _isFirstTime = false;
    _currentScreen = AppScreen.home;
    notifyListeners();
    _saveState();
  }

  void logout() {
    _currentScreen = AppScreen.login;
    notifyListeners();
    _saveState();
  }

  // Persistence methods
  Future<void> _saveState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isFirstTime', _isFirstTime);
      await prefs.setString('userName', _userName);
      await prefs.setInt('userLevel', _level);
      await prefs.setInt('userXP', _experience);
      await prefs.setInt('streakDays', _streak);
      await prefs.setInt('completedSessions', _sessionsToday);
      await prefs.setInt('dailyGoal', _dailyGoal);
      await prefs.setInt('totalSessions', _totalSessions);
      await prefs.setStringList('achievements', _achievements);

      // Save exercise stats
      for (String key in _exerciseStats.keys) {
        await prefs.setInt('exercise_$key', _exerciseStats[key]!);
      }
    } catch (e) {
      print('Error saving app state: $e');
    }
  }

  Future<void> loadState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isFirstTime = prefs.getBool('isFirstTime') ?? true;
      _userName = prefs.getString('userName') ?? '';
      _level = prefs.getInt('userLevel') ?? 12;
      _experience = prefs.getInt('userXP') ?? 2750;
      _streak = prefs.getInt('streakDays') ?? 25;
      _sessionsToday = prefs.getInt('completedSessions') ?? 4;
      _dailyGoal = prefs.getInt('dailyGoal') ?? 5;
      _totalSessions = prefs.getInt('totalSessions') ?? 156;
      _achievements = prefs.getStringList('achievements') ?? [];

      // Load exercise stats
      final keys = prefs.getKeys().where((key) => key.startsWith('exercise_'));
      for (String key in keys) {
        final exerciseType = key.replaceFirst('exercise_', '');
        _exerciseStats[exerciseType] = prefs.getInt(key) ?? 0;
      }

      notifyListeners();
    } catch (e) {
      print('Error loading app state: $e');
    }
  }

  // Helper methods
  double get progressToNextLevel {
    return (_experience % 100) / 100.0;
  }

  int get xpToNextLevel {
    return 100 - (_experience % 100);
  }

  bool hasAchievement(String achievementId) {
    return _achievements.contains(achievementId);
  }

  int getExerciseCount(String exerciseType) {
    return _exerciseStats[exerciseType] ?? 0;
  }

  double get dailyProgress {
    return _sessionsToday / _dailyGoal;
  }

  bool get isDailyGoalComplete {
    return _sessionsToday >= _dailyGoal;
  }
}
