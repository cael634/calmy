import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum TimeMode {
  morning,
  afternoon,
  night,
}

class TimeModeProvider extends ChangeNotifier {
  TimeMode _currentMode = TimeMode.morning;

  TimeMode get currentMode => _currentMode;

  TimeModeProvider() {
    _loadTimeMode();
  }

  void setTimeMode(TimeMode mode) {
    _currentMode = mode;
    notifyListeners();
    _saveTimeMode();
  }

  void setMode(TimeMode mode) {
    setTimeMode(mode);
  }

  // Get gradient colors based on time mode
  List<Color> get currentGradient {
    switch (_currentMode) {
      case TimeMode.morning:
        return [
          const Color(0xFFFFE082),
          const Color(0xFFFFB74D),
          const Color(0xFFFF8A65),
        ];
      case TimeMode.afternoon:
        return [
          const Color(0xFF81C784),
          const Color(0xFF4FC3F7),
          const Color(0xFF29B6F6),
        ];
      case TimeMode.night:
        return [
          const Color(0xFF7986CB),
          const Color(0xFF5C6BC0),
          const Color(0xFF3F51B5),
        ];
    }
  }

  // Get background decoration
  BoxDecoration get backgroundDecoration {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: currentGradient,
      ),
    );
  }

  // Get greeting message
  String get greetingMessage {
    switch (_currentMode) {
      case TimeMode.morning:
        return 'Buenos días';
      case TimeMode.afternoon:
        return 'Buenas tardes';
      case TimeMode.night:
        return 'Buenas noches';
    }
  }

  String getGreeting(bool isSpanish) {
    switch (_currentMode) {
      case TimeMode.morning:
        return isSpanish ? 'Buenos días, Zenith te saluda!' : 'Good morning, Zenith greets you!';
      case TimeMode.afternoon:
        return isSpanish ? 'Buenas tardes, Zenith te saluda!' : 'Good afternoon, Zenith greets you!';
      case TimeMode.night:
        return isSpanish ? 'Buenas noches, Zenith te saluda!' : 'Good night, Zenith greets you!';
    }
  }

  // Get decorative elements
  List<Widget> get decorativeElements {
    switch (_currentMode) {
      case TimeMode.morning:
        return [
          Positioned(
            top: 100,
            right: 30,
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.yellow.withOpacity(0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.wb_sunny,
                color: Colors.white,
                size: 40,
              ),
            ),
          ),
          Positioned(
            top: 200,
            left: 20,
            child: Icon(
              Icons.cloud,
              color: Colors.white.withOpacity(0.6),
              size: 30,
            ),
          ),
        ];
      case TimeMode.afternoon:
        return [
          Positioned(
            top: 120,
            right: 40,
            child: Icon(
              Icons.wb_sunny_outlined,
              color: Colors.white.withOpacity(0.7),
              size: 50,
            ),
          ),
          Positioned(
            top: 180,
            left: 30,
            child: Icon(
              Icons.nature,
              color: Colors.white.withOpacity(0.6),
              size: 35,
            ),
          ),
        ];
      case TimeMode.night:
        return [
          Positioned(
            top: 100,
            right: 30,
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.yellow.withOpacity(0.8),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.nightlight_round,
                color: Colors.white,
                size: 40,
              ),
            ),
          ),
          Positioned(
            top: 150,
            left: 20,
            child: Icon(
              Icons.star,
              color: Colors.white.withOpacity(0.8),
              size: 25,
            ),
          ),
          Positioned(
            top: 220,
            left: 50,
            child: Icon(
              Icons.star,
              color: Colors.white.withOpacity(0.6),
              size: 20,
            ),
          ),
        ];
    }
  }

  // Get primary color for the mode
  Color get primaryColor {
    switch (_currentMode) {
      case TimeMode.morning:
        return const Color(0xFFFF8A65);
      case TimeMode.afternoon:
        return const Color(0xFF29B6F6);
      case TimeMode.night:
        return const Color(0xFF3F51B5);
    }
  }

  // Get secondary color for the mode
  Color get secondaryColor {
    switch (_currentMode) {
      case TimeMode.morning:
        return const Color(0xFFFFE082);
      case TimeMode.afternoon:
        return const Color(0xFF81C784);
      case TimeMode.night:
        return const Color(0xFF7986CB);
    }
  }

  // Get progress bar colors
  List<Color> getProgressColors() {
    switch (_currentMode) {
      case TimeMode.morning:
        return [const Color(0xFF4CAF50), const Color(0xFF8BC34A)];
      case TimeMode.afternoon:
        return [const Color(0xFFFF9800), const Color(0xFFE91E63)];
      case TimeMode.night:
        return [const Color(0xFF9C27B0), const Color(0xFFE91E63)];
    }
  }

  // Persistence methods
  Future<void> _saveTimeMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('timeMode', _currentMode.toString());
    } catch (e) {
      print('Error saving time mode: $e');
    }
  }

  Future<void> _loadTimeMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedMode = prefs.getString('timeMode');
      if (savedMode != null) {
        switch (savedMode) {
          case 'TimeMode.morning':
            _currentMode = TimeMode.morning;
            break;
          case 'TimeMode.afternoon':
            _currentMode = TimeMode.afternoon;
            break;
          case 'TimeMode.night':
            _currentMode = TimeMode.night;
            break;
        }
        notifyListeners();
      }
    } catch (e) {
      print('Error loading time mode: $e');
    }
  }

  Future<void> loadMode() async {
    await _loadTimeMode();
  }
}
