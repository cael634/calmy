import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:calmy/providers/app_state.dart' ;
import 'providers/pet_provider.dart';
import 'providers/time_mode_provider.dart';
import 'providers/language_provider.dart';
import 'screens/home_screen.dart';
import 'screens/introduction_screen.dart';
import 'screens/breathing_exercise_screen.dart';
import 'screens/mood_tracker_screen.dart';
import 'screens/pet_customization_screen.dart';
import 'screens/achievements_screen.dart';
import 'screens/sleep_exercises_screen.dart';
import 'screens/emergency_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import '../models/app_screen.dart 'as models;
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
        ChangeNotifierProvider(create: (_) => PetProvider()),
        ChangeNotifierProvider(create: (_) => TimeModeProvider()),
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
      ],
      child: Consumer<LanguageProvider>(
        builder: (context, languageProvider, child) {
          return MaterialApp(
            title: 'Calmy',
            locale: languageProvider.currentLocale,
            theme: ThemeData(
              primarySwatch: Colors.purple,
              fontFamily: 'Poppins',
            ),
            home: WillPopScope(
              onWillPop: () async {
                final appState = Provider.of<AppState>(context, listen: false);

                // If we're not on home or introduction screen, go back to home
                if (appState.currentScreen != models.AppScreen.home &&
                    appState.currentScreen != models.AppScreen.introduction) {
                  appState.navigateToHome();
                  return false; // Don't exit the app
                }

                // If we're on home or introduction, allow exit
                return true;
              },
              child: Consumer<AppState>(
                builder: (context, appState, child) {
                  if (appState.isFirstTime) {
                    return const IntroductionScreen();
                  }

                  switch (appState?.currentScreen) {
                    case models.AppScreen.home:
                      return const HomeScreen();
                    case models.AppScreen.breathingBubble:
                      return const BreathingExerciseScreen(exerciseType: 'bubble');
                    case models.AppScreen.breathingTriangle:
                      return const BreathingExerciseScreen(exerciseType: 'triangle');
                    case models.AppScreen.moodTracker:
                      return const MoodTrackerScreen();
                    case models.AppScreen.petCustomization:
                      return const PetCustomizationScreen();
                    case models.AppScreen.achievements:
                      return const AchievementsScreen();
                    case models.AppScreen.sleepExercises:
                      return const SleepExercisesScreen();
                    case models.AppScreen.emergency:
                      return const EmergencyScreen();
                    case models.AppScreen.login:
                      return const LoginScreen();
                    case models.AppScreen.register:
                      return const RegisterScreen();
                    case models.AppScreen.introduction:
                      return const IntroductionScreen();
                    default:
                      return const HomeScreen();
                  }
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
