import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/pet_provider.dart';

class PetAvatar extends StatelessWidget {
  final double size;
  final bool showHeart;
  final bool showAura;
  final PetProvider? petProvider;

  const PetAvatar({
    Key? key,
    this.size = 80,
    this.showHeart = false,
    this.showAura = false,
    this.petProvider,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PetProvider>(
      builder: (context, provider, child) {
        final pet = petProvider ?? provider;

        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [
                Colors.white.withOpacity(0.8),
                Colors.purple.withOpacity(0.3),
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.purple.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Pet emoji
              Text(
                pet.getPetEmoji(),
                style: TextStyle(fontSize: size * 0.6),
              ),

              // Aura effect
              if (showAura && pet.getAuraEmoji().isNotEmpty)
                Positioned(
                  top: size * 0.1,
                  right: size * 0.1,
                  child: Text(
                    pet.getAuraEmoji(),
                    style: TextStyle(fontSize: size * 0.3),
                  ),
                ),

              // Hat
              if (pet.getHatEmoji().isNotEmpty)
                Positioned(
                  top: size * 0.05,
                  child: Text(
                    pet.getHatEmoji(),
                    style: TextStyle(fontSize: size * 0.4),
                  ),
                ),

              // Clothes
              if (pet.getClothesEmoji().isNotEmpty)
                Positioned(
                  bottom: size * 0.2,
                  child: Text(
                    pet.getClothesEmoji(),
                    style: TextStyle(fontSize: size * 0.3),
                  ),
                ),

              // Heart indicator
              if (showHeart)
                Positioned(
                  top: size * 0.1,
                  left: size * 0.1,
                  child: const Text('💖', style: TextStyle(fontSize: 16)),
                ),
            ],
          ),
        );
      },
    );
  }
}
