import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/time_mode_provider.dart';

class TimeModeSelector extends StatelessWidget {
  const TimeModeSelector({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<TimeModeProvider>(
      builder: (context, timeModeProvider, child) {
        return Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(25),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildModeButton(
                context,
                timeModeProvider,
                TimeMode.morning,
                Icons.wb_sunny,
              ),
              _buildModeButton(
                context,
                timeModeProvider,
                TimeMode.afternoon,
                Icons.wb_sunny_outlined,
              ),
              _buildModeButton(
                context,
                timeModeProvider,
                TimeMode.night,
                Icons.nightlight_round,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildModeButton(
      BuildContext context,
      TimeModeProvider provider,
      TimeMode mode,
      IconData icon,
      ) {
    final isSelected = provider.currentMode == mode;

    return GestureDetector(
      onTap: () => provider.setTimeMode(mode),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white.withOpacity(0.9) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Icon(
          icon,
          color: isSelected ? provider.primaryColor : Colors.white.withOpacity(0.7),
          size: 24,
        ),
      ),
    );
  }
}
