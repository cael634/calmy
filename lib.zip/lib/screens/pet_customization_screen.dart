import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/pet_provider.dart';
import '../providers/language_provider.dart';
import 'package:calmy/providers/app_state.dart' ;
import '../widgets/gradient_background.dart';
import '../widgets/pet_avatar.dart';
import '../models/app_screen.dart' as models;

class PetCustomizationScreen extends StatefulWidget {
  const PetCustomizationScreen({super.key});

  @override
  State<PetCustomizationScreen> createState() => _PetCustomizationScreenState();
}

class _PetCustomizationScreenState extends State<PetCustomizationScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final petProvider = Provider.of<PetProvider>(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final appState = Provider.of<AppState>(context);
    final isSpanish = languageProvider.isSpanish;

    return Scaffold(
      body: GradientBackground(
        colors: const [
          Color(0xFFE1BEE7),
          Color(0xFFF8BBD9),
          Color(0xFFFFCDD2),
        ],
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Provider.of<AppState>(context, listen: false).navigateTo(models.AppScreen.home),
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    Expanded(
                      child: Text(
                        isSpanish ? 'Personalizar Mascota' : 'Customize Pet',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),
              
              // Pet preview
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    PetAvatar(
                      petProvider: petProvider,
                      size: 120,
                      showHeart: true,
                    ).animate().scale(duration: 600.ms),
                    const SizedBox(height: 16),
                    Text(
                      petProvider.config.name,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.purple,
                      ),
                    ),
                    Text(
                      '${isSpanish ? 'Nivel' : 'Level'} ${appState.level}',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Tabs
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  labelColor: Colors.purple,
                  unselectedLabelColor: Colors.grey,
                  indicator: BoxDecoration(
                    color: Colors.purple[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  tabs: [
                    Tab(text: isSpanish ? 'Auras' : 'Auras'),
                    Tab(text: isSpanish ? 'Colores' : 'Colors'),
                    Tab(text: isSpanish ? 'Mascotas' : 'Pets'),
                    Tab(text: isSpanish ? 'Sombreros' : 'Hats'),
                    Tab(text: isSpanish ? 'Ropa' : 'Clothes'),
                  ],
                ),
              ),
              
              // Tab content
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildAurasTab(petProvider, appState, isSpanish),
                      _buildColorsTab(petProvider, appState, isSpanish),
                      _buildPetsTab(petProvider, appState, isSpanish),
                      _buildHatsTab(petProvider, appState, isSpanish),
                      _buildClothesTab(petProvider, appState, isSpanish),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAurasTab(PetProvider petProvider, AppState appState, bool isSpanish) {
    final auras = [
      {'id': 'none', 'emoji': '❌', 'nameES': 'Sin aura', 'nameEN': 'No aura', 'level': 1},
      {'id': 'sparkles', 'emoji': '✨', 'nameES': 'Destellos', 'nameEN': 'Sparkles', 'level': 3},
      {'id': 'hearts', 'emoji': '💕', 'nameES': 'Corazones', 'nameEN': 'Hearts', 'level': 5},
      {'id': 'stars', 'emoji': '⭐', 'nameES': 'Estrellas', 'nameEN': 'Stars', 'level': 8},
      {'id': 'rainbow', 'emoji': '🌈', 'nameEN': 'Rainbow', 'nameES': 'Arcoíris', 'level': 12},
    ];

    return _buildCustomizationGrid(
      items: auras,
      currentSelection: petProvider.config.aura,
      onSelect: (id) => petProvider.updateAura(id),
      appState: appState,
      isSpanish: isSpanish,
    );
  }

  Widget _buildColorsTab(PetProvider petProvider, AppState appState, bool isSpanish) {
    final colors = [
      {'id': '#FF6B6B', 'emoji': '🔴', 'nameES': 'Rojo', 'nameEN': 'Red', 'level': 1},
      {'id': '#4ECDC4', 'emoji': '🔵', 'nameES': 'Azul', 'nameEN': 'Blue', 'level': 1},
      {'id': '#45B7D1', 'emoji': '💙', 'nameES': 'Azul cielo', 'nameEN': 'Sky blue', 'level': 2},
      {'id': '#96CEB4', 'emoji': '💚', 'nameES': 'Verde', 'nameEN': 'Green', 'level': 3},
      {'id': '#FFEAA7', 'emoji': '💛', 'nameES': 'Amarillo', 'nameEN': 'Yellow', 'level': 4},
      {'id': '#DDA0DD', 'emoji': '💜', 'nameES': 'Púrpura', 'nameEN': 'Purple', 'level': 6},
      {'id': 'linear-gradient(45deg, #FF6B6B, #4ECDC4)', 'emoji': '🌈', 'nameES': 'Gradiente', 'nameEN': 'Gradient', 'level': 10},
    ];

    return _buildCustomizationGrid(
      items: colors,
      currentSelection: petProvider.config.color,
      onSelect: (id) => petProvider.updateColor(id),
      appState: appState,
      isSpanish: isSpanish,
    );
  }

  Widget _buildPetsTab(PetProvider petProvider, AppState appState, bool isSpanish) {
    final pets = [
      {'id': 'cat', 'emoji': '🐱', 'nameES': 'Gato', 'nameEN': 'Cat', 'level': 1},
      {'id': 'dog', 'emoji': '🐶', 'nameES': 'Perro', 'nameEN': 'Dog', 'level': 2},
      {'id': 'rabbit', 'emoji': '🐰', 'nameES': 'Conejo', 'nameEN': 'Rabbit', 'level': 4},
      {'id': 'fox', 'emoji': '🦊', 'nameES': 'Zorro', 'nameEN': 'Fox', 'level': 6},
      {'id': 'panda', 'emoji': '🐼', 'nameES': 'Panda', 'nameEN': 'Panda', 'level': 8},
      {'id': 'unicorn', 'emoji': '🦄', 'nameES': 'Unicornio', 'nameEN': 'Unicorn', 'level': 15},
    ];

    return _buildCustomizationGrid(
      items: pets,
      currentSelection: petProvider.config.type,
      onSelect: (id) => petProvider.updateType(id),
      appState: appState,
      isSpanish: isSpanish,
    );
  }

  Widget _buildHatsTab(PetProvider petProvider, AppState appState, bool isSpanish) {
    final hats = [
      {'id': 'none', 'emoji': '❌', 'nameES': 'Sin sombrero', 'nameEN': 'No hat', 'level': 1},
      {'id': 'cap', 'emoji': '🧢', 'nameES': 'Gorra', 'nameEN': 'Cap', 'level': 3},
      {'id': 'crown', 'emoji': '👑', 'nameES': 'Corona', 'nameEN': 'Crown', 'level': 7},
      {'id': 'wizard', 'emoji': '🎩', 'nameES': 'Mago', 'nameEN': 'Wizard', 'level': 10},
    ];

    return _buildCustomizationGrid(
      items: hats,
      currentSelection: petProvider.config.hat,
      onSelect: (id) => petProvider.updateHat(id),
      appState: appState,
      isSpanish: isSpanish,
    );
  }

  Widget _buildClothesTab(PetProvider petProvider, AppState appState, bool isSpanish) {
    final clothes = [
      {'id': 'none', 'emoji': '❌', 'nameES': 'Sin ropa', 'nameEN': 'No clothes', 'level': 1},
      {'id': 'scarf', 'emoji': '🧣', 'nameES': 'Bufanda', 'nameEN': 'Scarf', 'level': 4},
      {'id': 'bow', 'emoji': '🎀', 'nameES': 'Moño', 'nameEN': 'Bow', 'level': 6},
      {'id': 'cape', 'emoji': '🦸', 'nameES': 'Capa', 'nameEN': 'Cape', 'level': 12},
    ];

    return _buildCustomizationGrid(
      items: clothes,
      currentSelection: petProvider.config.clothes,
      onSelect: (id) => petProvider.updateClothes(id),
      appState: appState,
      isSpanish: isSpanish,
    );
  }

  Widget _buildCustomizationGrid({
    required List<Map<String, dynamic>> items,
    required String currentSelection,
    required Function(String) onSelect,
    required AppState appState,
    required bool isSpanish,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.8,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          final isSelected = currentSelection == item['id'];
          final isUnlocked = appState.level >= item['level'];
          
          return GestureDetector(
            onTap: isUnlocked ? () => onSelect(item['id']) : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: isSelected 
                    ? Colors.purple[100]
                    : (isUnlocked ? Colors.grey[50] : Colors.grey[200]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected 
                      ? Colors.purple
                      : (isUnlocked ? Colors.grey[300]! : Colors.grey[400]!),
                  width: isSelected ? 3 : 1,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    children: [
                      Text(
                        item['emoji'],
                        style: TextStyle(
                          fontSize: 40,
                          color: isUnlocked ? null : Colors.grey,
                        ),
                      ),
                      if (!isUnlocked)
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.lock,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isSpanish ? item['nameES'] : item['nameEN'],
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      color: isUnlocked 
                          ? (isSelected ? Colors.purple : Colors.grey[700])
                          : Colors.grey[500],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${isSpanish ? 'Nivel' : 'Level'} ${item['level']}',
                    style: TextStyle(
                      fontSize: 10,
                      color: isUnlocked ? Colors.grey[600] : Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
          ).animate(delay: (index * 50).ms).scale();
        },
      ),
    );
  }
}
