import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:calmy/providers/app_state.dart';
import '../providers/pet_provider.dart';
import '../providers/time_mode_provider.dart';
import '../providers/language_provider.dart';
import '../widgets/gradient_background.dart';
import '../widgets/time_mode_selector.dart';
import '../widgets/pet_avatar.dart';
import '../models/app_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer4<AppState, PetProvider, TimeModeProvider, LanguageProvider>(
        builder: (context, appState, petProvider, timeModeProvider, languageProvider, child) {
          return GradientBackground(
            colors: timeModeProvider.currentGradient,
            child: SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      _buildHeader(context, appState, petProvider, timeModeProvider, languageProvider),
                      const SizedBox(height: 30),
                      _buildStatsCards(context, appState, languageProvider),
                      const SizedBox(height: 30),
                      _buildProgressCard(context, appState, languageProvider),
                      const SizedBox(height: 30),
                      _buildExerciseCards(context, appState, languageProvider),
                      const SizedBox(height: 30),
                      _buildQuickActions(context, appState, languageProvider),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader(BuildContext context, AppState appState, PetProvider petProvider, TimeModeProvider timeModeProvider, LanguageProvider languageProvider) {
    return Column(
      children: [
        const TimeModeSelector(),
        const SizedBox(height: 20),
        // Pet Avatar (single circle)
        PetAvatar(size: 120, petProvider: petProvider, showHeart: true),
        const SizedBox(height: 20),
        Text(
          '${timeModeProvider.getGreeting(languageProvider.isSpanish)} 👋',
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10),
        Text(
          languageProvider.isSpanish ? '¿Qué te gustaría hacer hoy?' : 'What would you like to do today?',
          style: TextStyle(
            fontSize: 16,
            color: Colors.white.withOpacity(0.9),
          ),
        ),
      ],
    );
  }

  Widget _buildStatsCards(BuildContext context, AppState appState, LanguageProvider languageProvider) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            '${appState.level}',
            languageProvider.isSpanish ? 'Nivel' : 'Level',
            Icons.trending_up,
          ),
        ),
        const SizedBox(width: 15),
        Expanded(
          child: _buildStatCard(
            '${appState.streak}',
            languageProvider.isSpanish ? 'Días seguidos 🔥' : 'Day streak 🔥',
            Icons.local_fire_department,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, size: 30, color: Colors.purple),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard(BuildContext context, AppState appState, LanguageProvider languageProvider) {
    final progress = appState.completedSessions / appState.dailyGoal;
    final progressPercentage = (progress * 100).clamp(0, 100).toInt();

    return Container(
      padding: const EdgeInsets.all(25),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                languageProvider.isSpanish ? 'Progreso de Hoy' : 'Today\'s Progress',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const Icon(Icons.star, color: Colors.amber, size: 24),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            '${languageProvider.isSpanish ? 'Meta' : 'Goal'}: ${appState.dailyGoal} ${languageProvider.isSpanish ? 'sesiones diarias' : 'daily sessions'}',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                languageProvider.isSpanish ? 'Sesiones completadas' : 'Sessions completed',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[700],
                ),
              ),
              Text(
                '${appState.completedSessions}/${appState.dailyGoal}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.grey[300],
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.purple),
            minHeight: 8,
          ),
          const SizedBox(height: 10),
          Text(
            appState.completedSessions >= appState.dailyGoal
                ? (languageProvider.isSpanish ? '¡Meta completada! 🎉' : 'Goal completed! 🎉')
                : (languageProvider.isSpanish ? '¡Solo falta ${appState.dailyGoal - appState.completedSessions} sesión${appState.dailyGoal - appState.completedSessions == 1 ? '' : 'es'} más!' : 'Just ${appState.dailyGoal - appState.completedSessions} more session${appState.dailyGoal - appState.completedSessions == 1 ? '' : 's'}!'),
            style: TextStyle(
              fontSize: 14,
              color: appState.completedSessions >= appState.dailyGoal ? Colors.green : Colors.purple,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            '$progressPercentage% ${languageProvider.isSpanish ? 'completado' : 'completed'}',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.purple,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseCards(BuildContext context, AppState appState, LanguageProvider languageProvider) {
    return Column(
      children: [
        _buildExerciseCard(
          context,
          appState,
          languageProvider.isSpanish ? 'Respiración Burbuja' : 'Bubble Breathing',
          languageProvider.isSpanish ? 'Técnica circular relajante' : 'Relaxing circular technique',
          Icons.bubble_chart,
          const LinearGradient(
            colors: [Color(0xFF667eea), Color(0xFF764ba2)],
          ),
          AppScreen.breathingBubble,
          languageProvider.isSpanish ? '4-7-8 respiración ✨' : '4-7-8 breathing ✨',
        ),
        const SizedBox(height: 15),
        _buildExerciseCard(
          context,
          appState,
          languageProvider.isSpanish ? 'Ejercicios para Dormir' : 'Sleep Exercises',
          languageProvider.isSpanish ? 'Relajación nocturna' : 'Night relaxation',
          Icons.bedtime,
          const LinearGradient(
            colors: [Color(0xFF2196F3), Color(0xFF21CBF3)],
          ),
          AppScreen.sleepExercises,
          languageProvider.isSpanish ? 'Sueño reparador 🌙' : 'Restful sleep 🌙',
        ),
      ],
    );
  }

  Widget _buildExerciseCard(
      BuildContext context,
      AppState appState,
      String title,
      String subtitle,
      IconData icon,
      LinearGradient gradient,
      AppScreen screen,
      String badge,
      ) {
    return GestureDetector(
      onTap: () => appState.navigateToScreen(screen),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: gradient.colors.isNotEmpty
              ? LinearGradient(
            colors: gradient.colors.map((c) => c.withOpacity(0.9)).toList(),
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
              : null,
          color: gradient.colors.isEmpty ? Colors.white.withOpacity(0.95) : null,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(
                icon,
                size: 30,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                badge,
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Icon(
              Icons.arrow_forward_ios,
              color: Colors.white,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context, AppState appState, LanguageProvider languageProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          languageProvider.isSpanish ? 'Acciones Rápidas' : 'Quick Actions',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 15),
        Row(
          children: [
            Expanded(
              child: _buildQuickActionButton(
                context,
                appState,
                languageProvider.isSpanish ? 'Estado de Ánimo' : 'Mood Tracker',
                Icons.mood,
                AppScreen.moodTracker,
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: _buildQuickActionButton(
                context,
                appState,
                languageProvider.isSpanish ? 'Personalizar' : 'Customize',
                Icons.pets,
                AppScreen.petCustomization,
              ),
            ),
          ],
        ),
        const SizedBox(height: 15),
        Row(
          children: [
            Expanded(
              child: _buildQuickActionButton(
                context,
                appState,
                languageProvider.isSpanish ? 'Logros' : 'Achievements',
                Icons.emoji_events,
                AppScreen.achievements,
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: _buildQuickActionButton(
                context,
                appState,
                languageProvider.isSpanish ? 'Emergencia' : 'Emergency',
                Icons.emergency,
                AppScreen.emergency,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickActionButton(
      BuildContext context,
      AppState appState,
      String title,
      IconData icon,
      AppScreen screen,
      ) {
    return GestureDetector(
      onTap: () => appState.navigateToScreen(screen),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.95),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 30,
              color: Colors.purple,
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
