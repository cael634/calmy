import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/language_provider.dart';
import 'package:calmy/providers/app_state.dart' ;
import '../widgets/gradient_background.dart';
import '../models/app_screen.dart';

class SleepExercisesScreen extends StatefulWidget {
  const SleepExercisesScreen({super.key});

  @override
  State<SleepExercisesScreen> createState() => _SleepExercisesScreenState();
}

class _SleepExercisesScreenState extends State<SleepExercisesScreen>
    with TickerProviderStateMixin {
  late AnimationController _moonController;
  late AnimationController _starsController;
  late Animation<double> _moonAnimation;
  late Animation<double> _starsAnimation;

  String _selectedExercise = '';
  bool _isPlaying = false;
  int _timer = 0;

  @override
  void initState() {
    super.initState();

    _moonController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );

    _starsController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _moonAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _moonController,
      curve: Curves.easeInOut,
    ));

    _starsAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _starsController,
      curve: Curves.easeInOut,
    ));

    _moonController.repeat(reverse: true);
    _starsController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _moonController.dispose();
    _starsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isSpanish = languageProvider.isSpanish;

    return Scaffold(
      body: GradientBackground(
        colors: const [
          Color(0xFF1A237E),
          Color(0xFF3F51B5),
          Color(0xFF673AB7),
        ],
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Provider.of<AppState>(context, listen: false).navigateTo(AppScreen.home),
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    Expanded(
                      child: Text(
                        isSpanish ? 'Ejercicios para Dormir' : 'Sleep Exercises',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              // Night scene
              Container(
                height: 200,
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.indigo[900],
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    // Stars
                    ...List.generate(20, (index) {
                      return Positioned(
                        left: (index * 37.0) % 300,
                        top: (index * 23.0) % 150,
                        child: AnimatedBuilder(
                          animation: _starsAnimation,
                          builder: (context, child) {
                            return Opacity(
                              opacity: _starsAnimation.value,
                              child: const Text('⭐', style: TextStyle(fontSize: 12)),
                            );
                          },
                        ),
                      );
                    }),

                    // Moon
                    Positioned(
                      right: 30,
                      top: 30,
                      child: AnimatedBuilder(
                        animation: _moonAnimation,
                        builder: (context, child) {
                          return Transform.scale(
                            scale: _moonAnimation.value,
                            child: const Text('🌙', style: TextStyle(fontSize: 60)),
                          );
                        },
                      ),
                    ),

                    // Welcome message
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            isSpanish ? 'Buenas noches' : 'Good night',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            isSpanish
                                ? 'Prepárate para un sueño reparador'
                                : 'Prepare for a restful sleep',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 16,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 200.ms),

              // Sleep exercises
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildSleepExerciseCard(
                        id: 'progressive_relaxation',
                        icon: '🧘‍♀️',
                        title: isSpanish ? 'Relajación Progresiva' : 'Progressive Relaxation',
                        subtitle: isSpanish ? '15 min • Relaja cada músculo' : '15 min • Relax every muscle',
                        description: isSpanish
                            ? 'Técnica que te ayuda a relajar todo tu cuerpo paso a paso'
                            : 'Technique that helps you relax your entire body step by step',
                        duration: 15,
                        isSpanish: isSpanish,
                      ).animate().slideX(begin: -0.3, delay: 300.ms),

                      const SizedBox(height: 16),

                      _buildSleepExerciseCard(
                        id: 'body_scan',
                        icon: '🌊',
                        title: isSpanish ? 'Escaneo Corporal' : 'Body Scan',
                        subtitle: isSpanish ? '10 min • Conciencia corporal' : '10 min • Body awareness',
                        description: isSpanish
                            ? 'Observa las sensaciones de tu cuerpo para liberar tensiones'
                            : 'Observe your body sensations to release tension',
                        duration: 10,
                        isSpanish: isSpanish,
                      ).animate().slideX(begin: 0.3, delay: 400.ms),

                      const SizedBox(height: 16),

                      _buildSleepExerciseCard(
                        id: 'breathing_4_7_8',
                        icon: '💤',
                        title: isSpanish ? 'Respiración 4-7-8' : '4-7-8 Breathing',
                        subtitle: isSpanish ? '5 min • Técnica para dormir' : '5 min • Sleep technique',
                        description: isSpanish
                            ? 'Respiración especial diseñada para inducir el sueño'
                            : 'Special breathing designed to induce sleep',
                        duration: 5,
                        isSpanish: isSpanish,
                      ).animate().slideX(begin: -0.3, delay: 500.ms),

                      const SizedBox(height: 16),

                      _buildSleepExerciseCard(
                        id: 'visualization',
                        icon: '🌸',
                        title: isSpanish ? 'Visualización Guiada' : 'Guided Visualization',
                        subtitle: isSpanish ? '12 min • Lugar tranquilo' : '12 min • Peaceful place',
                        description: isSpanish
                            ? 'Imagina un lugar sereno que te ayude a relajarte'
                            : 'Imagine a serene place that helps you relax',
                        duration: 12,
                        isSpanish: isSpanish,
                      ).animate().slideX(begin: 0.3, delay: 600.ms),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSleepExerciseCard({
    required String id,
    required String icon,
    required String title,
    required String subtitle,
    required String description,
    required int duration,
    required bool isSpanish,
  }) {
    final isSelected = _selectedExercise == id;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _startSleepExercise(id, duration, isSpanish),
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.indigo[100],
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Center(
                        child: Text(icon, style: const TextStyle(fontSize: 28)),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            subtitle,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.play_circle_filled,
                      color: Colors.indigo[400],
                      size: 32,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[700],
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.indigo[50],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '$duration ${isSpanish ? 'minutos' : 'minutes'}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.indigo[700],
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _startSleepExercise(String exerciseId, int duration, bool isSpanish) {
    setState(() {
      _selectedExercise = exerciseId;
      _isPlaying = true;
      _timer = duration * 60; // Convert to seconds
    });

    // Add experience points
    Provider.of<AppState>(context, listen: false).addExperience(40);

    // Show exercise dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _buildExerciseDialog(exerciseId, isSpanish),
    );
  }

  Widget _buildExerciseDialog(String exerciseId, bool isSpanish) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      backgroundColor: Colors.indigo[50],
      title: Row(
        children: [
          const Text('🌙', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          Text(
            isSpanish ? 'Ejercicio Iniciado' : 'Exercise Started',
            style: TextStyle(color: Colors.indigo[800]),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            isSpanish
                ? 'Tu ejercicio de sueño ha comenzado. Relájate y sigue las instrucciones.'
                : 'Your sleep exercise has started. Relax and follow the instructions.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.indigo[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.flash_on, color: Colors.orange),
                const SizedBox(width: 8),
                Text(
                  '+40 XP',
                  style: TextStyle(
                    color: Colors.indigo[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              _isPlaying = false;
              _selectedExercise = '';
            });
            Navigator.of(context).pop();
          },
          child: Text(isSpanish ? 'Cerrar' : 'Close'),
        ),
      ],
    );
  }
}
