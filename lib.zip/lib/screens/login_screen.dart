import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:calmy/providers/app_state.dart' ;
import '../providers/language_provider.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_input.dart';
import '../widgets/gradient_background.dart';
import '../models/app_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String? email;
  String? password;

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final appState = Provider.of<AppState>(context);
    final isSpanish = languageProvider.isSpanish;

    return Scaffold(
      body: GradientBackground(
        colors: const [
          Color(0xFFE3F2FD),
          Color(0xFFF3E5F5),
          Color(0xFFFCE4EC),
        ],
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const SizedBox(height: 60),

                  // Logo/Header
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFF8B5CF6), Color(0xFF3B82F6)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.purple.withOpacity(0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text('🧘‍♀️', style: TextStyle(fontSize: 60)),
                    ),
                  ).animate().scale(duration: 600.ms),

                  const SizedBox(height: 32),

                  Text(
                    isSpanish ? 'Bienvenido de vuelta' : 'Welcome back',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.purple[800],
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 200.ms),

                  const SizedBox(height: 8),

                  Text(
                    isSpanish ? 'Continúa tu viaje de bienestar' : 'Continue your wellness journey',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.purple[600],
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 400.ms),

                  const SizedBox(height: 48),

                  // Login form
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        CustomInput(
                          labelText: isSpanish ? 'Correo electrónico' : 'Email',
                          hintText: 'tu@email.com',
                          prefixIcon: Icons.email,
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Ingresa tu email' : 'Please enter your email';
                            }
                            if (!value.contains('@')) {
                              return isSpanish ? 'Ingresa un email válido' : 'Please enter a valid email';
                            }
                            email = value;
                            return null;
                          },
                        ),
                        const SizedBox(height: 20),
                        CustomInput(
                          labelText: isSpanish ? 'Contraseña' : 'Password',
                          hintText: '••••••••',
                          prefixIcon: Icons.lock,
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Ingresa tu contraseña' : 'Please enter your password';
                            }
                            if (value.length < 6) {
                              return isSpanish ? 'La contraseña debe tener al menos 6 caracteres' : 'Password must be at least 6 characters';
                            }
                            password = value;
                            return null;
                          },
                        ),
                        const SizedBox(height: 32),
                        CustomButton(
                          text: isSpanish ? 'Iniciar Sesión' : 'Login',
                          onPressed: () => _login(appState),
                          icon: Icons.login,
                        ),
                        const SizedBox(height: 16),
                        TextButton(
                          onPressed: () {
                            appState.navigateTo(AppScreen.register);
                          },
                          child: Text(
                            isSpanish ? '¿No tienes cuenta? Regístrate' : 'Don\'t have an account? Register',
                            style: TextStyle(
                              color: Colors.purple[600],
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().slideY(begin: 0.3, delay: 600.ms),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _login(AppState appState) {
    if (_formKey.currentState!.validate()) {
      appState.login();
    }
  }
}
