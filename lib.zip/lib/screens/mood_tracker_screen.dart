import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/language_provider.dart';
import 'package:calmy/providers/app_state.dart' ;
import '../widgets/gradient_background.dart';
import '../models/app_screen.dart';

class MoodTrackerScreen extends StatefulWidget {
  const MoodTrackerScreen({super.key});

  @override
  State<MoodTrackerScreen> createState() => _MoodTrackerScreenState();
}

class _MoodTrackerScreenState extends State<MoodTrackerScreen> {
  int _selectedMood = -1;
  final TextEditingController _reflectionController = TextEditingController();
  final TextEditingController _gratitudeController = TextEditingController();

  final List<Map<String, dynamic>> _moods = [
    {'emoji': '😢', 'labelES': 'Muy triste', 'labelEN': 'Very sad', 'color': Colors.blue[700]},
    {'emoji': '😔', 'labelES': 'Triste', 'labelEN': 'Sad', 'color': Colors.blue[500]},
    {'emoji': '😐', 'labelES': 'Neutral', 'labelEN': 'Neutral', 'color': Colors.grey[500]},
    {'emoji': '😊', 'labelES': 'Feliz', 'labelEN': 'Happy', 'color': Colors.green[500]},
    {'emoji': '😄', 'labelES': 'Muy feliz', 'labelEN': 'Very happy', 'color': Colors.green[700]},
  ];

  final List<String> _suggestionsES = [
    "Hoy me sentí agradecido por...",
    "Un momento que me hizo sonreír fue...",
    "Algo que aprendí sobre mí mismo hoy...",
    "Una pequeña victoria que tuve hoy...",
    "Me siento orgulloso de...",
    "Algo hermoso que noté hoy...",
  ];

  final List<String> _suggestionsEN = [
    "Today I felt grateful for...",
    "A moment that made me smile was...",
    "Something I learned about myself today...",
    "A small victory I had today...",
    "I feel proud of...",
    "Something beautiful I noticed today...",
  ];

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isSpanish = languageProvider.isSpanish;
    final suggestions = isSpanish ? _suggestionsES : _suggestionsEN;

    return Scaffold(
      body: GradientBackground(
        colors: const [
          Color(0xFFF8BBD9),
          Color(0xFFE1BEE7),
          Color(0xFFD1C4E9),
        ],
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Provider.of<AppState>(context, listen: false).navigateTo(AppScreen.home),
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    Expanded(
                      child: Text(
                        isSpanish ? 'Mini Diario de Autoestima' : 'Mini Self-Esteem Diary',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Mood selection
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('💭', style: TextStyle(fontSize: 24)),
                                const SizedBox(width: 8),
                                Text(
                                  isSpanish ? '¿Cómo te sientes hoy?' : 'How are you feeling today?',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: _moods.asMap().entries.map((entry) {
                                final index = entry.key;
                                final mood = entry.value;
                                final isSelected = _selectedMood == index;

                                return GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _selectedMood = index;
                                    });
                                  },
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 200),
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? mood['color'].withOpacity(0.2)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isSelected
                                            ? mood['color']
                                            : Colors.grey[300]!,
                                        width: 2,
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        Text(
                                          mood['emoji'],
                                          style: TextStyle(
                                            fontSize: isSelected ? 32 : 28,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          isSpanish ? mood['labelES'] : mood['labelEN'],
                                          style: TextStyle(
                                            fontSize: 10,
                                            color: isSelected
                                                ? mood['color']
                                                : Colors.grey[600],
                                            fontWeight: isSelected
                                                ? FontWeight.bold
                                                : FontWeight.normal,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ).animate(delay: (index * 100).ms).scale();
                              }).toList(),
                            ),
                          ],
                        ),
                      ).animate().slideY(begin: 0.3, delay: 200.ms),

                      const SizedBox(height: 20),

                      // Reflection section
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('✨', style: TextStyle(fontSize: 24)),
                                const SizedBox(width: 8),
                                Text(
                                  isSpanish ? 'Reflexión del día' : 'Daily reflection',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: _reflectionController,
                              maxLines: 4,
                              decoration: InputDecoration(
                                hintText: isSpanish
                                    ? 'Escribe sobre tu día, tus pensamientos o sentimientos...'
                                    : 'Write about your day, thoughts, or feelings...',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: Colors.purple[200]!),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: Colors.purple[200]!),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(color: Colors.purple),
                                ),
                                filled: true,
                                fillColor: Colors.purple[50],
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              isSpanish ? 'Sugerencias:' : 'Suggestions:',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.purple[700],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: suggestions.map((suggestion) {
                                return GestureDetector(
                                  onTap: () {
                                    _reflectionController.text = suggestion;
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.purple[100],
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: Colors.purple[200]!),
                                    ),
                                    child: Text(
                                      suggestion,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.purple[700],
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ).animate().slideY(begin: 0.3, delay: 400.ms),

                      const SizedBox(height: 20),

                      // Gratitude section
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('🙏', style: TextStyle(fontSize: 24)),
                                const SizedBox(width: 8),
                                Text(
                                  isSpanish ? 'Gratitud' : 'Gratitude',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              isSpanish
                                  ? 'Menciona algo por lo que te sientes agradecido hoy'
                                  : 'Mention something you feel grateful for today',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: _gratitudeController,
                              maxLines: 3,
                              decoration: InputDecoration(
                                hintText: isSpanish
                                    ? 'Hoy estoy agradecido por...'
                                    : 'Today I am grateful for...',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: Colors.green[200]!),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: Colors.green[200]!),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(color: Colors.green),
                                ),
                                filled: true,
                                fillColor: Colors.green[50],
                              ),
                            ),
                          ],
                        ),
                      ).animate().slideY(begin: 0.3, delay: 600.ms),

                      const SizedBox(height: 32),

                      // Save button
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _selectedMood >= 0 ? _saveEntry : null,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.purple,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 8,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.save),
                              const SizedBox(width: 8),
                              Text(
                                isSpanish ? 'Guardar entrada' : 'Save entry',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ).animate().slideY(begin: 0.3, delay: 800.ms),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveEntry() {
    if (_selectedMood >= 0) {
      // Add experience points
      Provider.of<AppState>(context, listen: false).addExperience(30);

      // Show success message
      final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
      final isSpanish = languageProvider.isSpanish;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.check_circle, color: Colors.white),
              const SizedBox(width: 8),
              Text(
                isSpanish
                    ? '¡Entrada guardada! +30 XP'
                    : 'Entry saved! +30 XP',
              ),
            ],
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );

      // Navigate back after a short delay
      Future.delayed(const Duration(seconds: 1), () {
        Provider.of<AppState>(context, listen: false).navigateTo(AppScreen.home);
      });
    }
  }

  @override
  void dispose() {
    _reflectionController.dispose();
    _gratitudeController.dispose();
    super.dispose();
  }
}
