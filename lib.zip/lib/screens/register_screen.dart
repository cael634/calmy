import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/app_screen.dart';
import '../providers/language_provider.dart';
import 'package:calmy/providers/app_state.dart' ;
import '../widgets/gradient_background.dart';
import 'login_screen.dart';
import 'home_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final appState = Provider.of<AppState>(context);
    final isSpanish = languageProvider.isSpanish;

    return Scaffold(
      body: GradientBackground(
        colors: const [
          Color(0xFFFCE4EC),
          Color(0xFFF3E5F5),
          Color(0xFFE8EAF6),
        ],
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const SizedBox(height: 40),
                  
                  // Header with decorative pet
                  Stack(
                    children: [
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [Color(0xFFF8BBD9), Color(0xFFE1BEE7)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.pink.withOpacity(0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text('🌸', style: TextStyle(fontSize: 60)),
                        ),
                      ),
                      Positioned(
                        top: -8,
                        right: -8,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                            color: Colors.pink,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.star,
                            color: Colors.white,
                            size: 20,
                          ),
                        ).animate().scale(delay: 600.ms).then().shimmer(),
                      ),
                    ],
                  ).animate().scale(duration: 600.ms),
                  
                  const SizedBox(height: 32),
                  
                  Text(
                    isSpanish ? 'Únete a Calmi' : 'Join Calmie',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.purple[800],
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 200.ms),
                  
                  const SizedBox(height: 8),
                  
                  Text(
                    isSpanish ? 'Comienza tu viaje hacia el bienestar' : 'Start your wellness journey',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.purple[600],
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 400.ms),
                  
                  const SizedBox(height: 40),
                  
                  // Welcome message
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFE91E63), Color(0xFF9C27B0)],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.purple.withOpacity(0.3),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Text(
                          isSpanish ? 'Únete a nuestra comunidad mindful' : 'Join our mindful community',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          isSpanish 
                              ? '¿Listo para comenzar tu transformación?' 
                              : 'Ready to begin your transformation?',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ).animate().slideY(begin: 0.3, delay: 600.ms),
                  
                  const SizedBox(height: 32),
                  
                  // Register form
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.favorite, color: Colors.purple),
                            const SizedBox(width: 8),
                            Text(
                              isSpanish ? 'Crear Cuenta' : 'Create Account',
                              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                color: Colors.purple[800],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 8),
                        
                        Text(
                          isSpanish ? 'Tu espacio personal de calma te está esperando' : 'Your personal calm space is waiting for you',
                          style: TextStyle(color: Colors.purple[600]),
                          textAlign: TextAlign.center,
                        ),
                        
                        const SizedBox(height: 24),
                        
                        // Name field
                        _buildFormField(
                          label: isSpanish ? 'Nombre completo' : 'Full name',
                          controller: _nameController,
                          icon: Icons.person,
                          hint: 'Tu nombre',
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Ingresa tu nombre' : 'Enter your name';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Email field
                        _buildFormField(
                          label: isSpanish ? 'Correo electrónico' : 'Email',
                          controller: _emailController,
                          icon: Icons.email,
                          hint: 'tu@email.com',
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Ingresa tu email' : 'Enter your email';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Password field
                        _buildFormField(
                          label: isSpanish ? 'Contraseña' : 'Password',
                          controller: _passwordController,
                          icon: Icons.lock,
                          hint: '••••••••',
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Ingresa tu contraseña' : 'Enter your password';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Confirm password field
                        _buildFormField(
                          label: isSpanish ? 'Confirmar contraseña' : 'Confirm password',
                          controller: _confirmPasswordController,
                          icon: Icons.lock,
                          hint: '••••••••',
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return isSpanish ? 'Confirma tu contraseña' : 'Confirm your password';
                            }
                            if (value != _passwordController.text) {
                              return isSpanish ? 'Las contraseñas no coinciden' : 'Passwords do not match';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 32),
                        
                        // Register button
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: () => _register(appState),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.purple,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 8,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.arrow_forward),
                                const SizedBox(width: 8),
                                Text(
                                  isSpanish ? 'Comenzar mi viaje zen' : 'Start my zen journey',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 16),
                        
                        // Login link
                        Center(
                          child: TextButton(
                            onPressed: () {
                              Provider.of<AppState>(context, listen: false).navigateTo(AppScreen.login);
                            },
                            child: Text(
                              isSpanish ? '¿Ya tienes cuenta? Iniciar sesión' : 'Already have an account? Sign in',
                              style: TextStyle(
                                color: Colors.purple[600],
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().slideY(begin: 0.3, delay: 800.ms),
                  
                  const SizedBox(height: 24),
                  
                  // Benefits card
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.purple[100]!, Colors.pink[100]!],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.purple[200]!),
                    ),
                    child: Column(
                      children: [
                        Text(
                          isSpanish ? '¿Qué encontrarás en Calmi?' : 'What will you find in Calmie?',
                          style: TextStyle(
                            color: Colors.purple[800],
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildBenefitItem('🧘‍♀️', isSpanish ? 'Ejercicios de respiración guiados' : 'Guided breathing exercises'),
                        _buildBenefitItem('🐱', isSpanish ? 'Tu mascota compañera personalizable' : 'Your customizable companion pet'),
                        _buildBenefitItem('📝', isSpanish ? 'Diario de autoestima y gratitud' : 'Self-esteem and gratitude diary'),
                        _buildBenefitItem('🏆', isSpanish ? 'Logros y desafíos motivadores' : 'Motivating achievements and challenges'),
                      ],
                    ),
                  ).animate().fadeIn(delay: 1000.ms),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    required String hint,
    bool obscureText = false,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.purple[700],
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: Colors.purple),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.purple[200]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.purple[200]!),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.purple),
            ),
            filled: true,
            fillColor: Colors.white.withOpacity(0.8),
          ),
          validator: validator,
        ),
      ],
    );
  }

  Widget _buildBenefitItem(String emoji, String text) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: Colors.purple[700],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _register(AppState appState) {
    if (_formKey.currentState!.validate()) {
      appState.login();
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
